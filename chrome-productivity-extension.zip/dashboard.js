window.onload = async () => {
  const res = await fetch('http://localhost:5000/summary');
  const data = await res.json();
  
  document.getElementById('summary').innerHTML = `
    <p>Productive Time: ${(data.productive || 0)/1000/60} mins</p>
    <p>Unproductive Time: ${(data.unproductive || 0)/1000/60} mins</p>
  `;
};