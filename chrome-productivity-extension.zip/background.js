let currentTabId = null;
let currentStartTime = null;

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  handleTabChange(tab);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    handleTabChange(tab);
  }
});

async function handleTabChange(tab) {
  const now = Date.now();

  if (currentTabId && currentStartTime) {
    const duration = now - currentStartTime;
    const url = (await chrome.tabs.get(currentTabId)).url;
    sendToBackend(url, duration);
  }

  currentTabId = tab.id;
  currentStartTime = now;
}

function sendToBackend(url, duration) {
  fetch('http://localhost:5000/track', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ url, duration })
  });
}