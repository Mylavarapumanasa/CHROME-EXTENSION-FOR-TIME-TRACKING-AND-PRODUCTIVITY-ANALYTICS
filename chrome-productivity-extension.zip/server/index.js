const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Activity = require('./models/Activity');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/productivity', { useNewUrlParser: true });

app.post('/track', async (req, res) => {
  const { url, duration } = req.body;
  const domain = new URL(url).hostname;

  const productiveSites = ['stackoverflow.com', 'github.com', 'leetcode.com'];
  const type = productiveSites.includes(domain) ? 'productive' : 'unproductive';

  await Activity.create({ domain, duration, type, timestamp: new Date() });
  res.sendStatus(200);
});

app.get('/summary', async (req, res) => {
  const lastWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const data = await Activity.find({ timestamp: { $gte: lastWeek } });

  const summary = data.reduce((acc, entry) => {
    acc[entry.type] = (acc[entry.type] || 0) + entry.duration;
    return acc;
  }, {});

  res.json(summary);
});

app.listen(5000, () => console.log('Server running on port 5000'));