const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
  domain: String,
  duration: Number,
  type: String,
  timestamp: Date
});

module.exports = mongoose.model('Activity', ActivitySchema);